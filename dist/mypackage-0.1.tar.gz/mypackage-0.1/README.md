# Python packages 

The is a demonstration on how to create packages in python.

## Installation process

